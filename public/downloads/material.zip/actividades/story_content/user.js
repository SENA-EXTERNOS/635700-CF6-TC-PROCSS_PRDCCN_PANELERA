function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6YRVmM6a8i8":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

