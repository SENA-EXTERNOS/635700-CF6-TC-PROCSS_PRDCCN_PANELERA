function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6F9jjjoDDKR":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

